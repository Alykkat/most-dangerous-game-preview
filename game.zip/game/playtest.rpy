## Automated playthroughs. Run with: renpy.py <this folder> test playthrough   (or: test ending)
## Screenshots go to tests/screenshots/. The playthrough stops on every scene and every change of
## staging (new pose, three figures on stage, sound effects) so each one can be checked by eye.

testcase playthrough:
    $ _test.transition_timeout = 0.05
    pause 3.0
    screenshot "s00_main_menu.png"
    click "Preferences"
    pause 1.0
    screenshot "s01_preferences.png"
    click "Load"
    pause 1.0
    screenshot "s02_load.png"
    click "Credits"
    pause 1.0
    screenshot "s03_credits_menu.png"
    move "The Toilers of the Sea"
    pause 0.5
    screenshot "s04_credits_hover.png"
    click "Return"
    pause 1.0
    click "Start"
    pause 1.0
    screenshot "s05_title_card.png"
    advance
    advance
    pause 1.2
    screenshot "s06_chapter_card.png"

    # I. Ship-Trap Island
    advance until "Off there to the right"
    pause 1.5
    screenshot "c1_01_yacht_whitney.png"
    advance until "What island is it"
    pause 1.0
    screenshot "c1_02_yacht_two.png"
    click "Scene Info"
    pause 1.0
    screenshot "c1_03_scene_info_yacht.png"
    click "Close"
    pause 0.5
    click "Scene Info"
    pause 0.8
    move "View at The Met"
    pause 0.5
    screenshot "c1_04_scene_info_link_hover.png"
    move pos (300, 500)
    click
    pause 0.6
    screenshot "c1_05_scene_info_closed_by_backdrop.png"
    advance until "Yes, even that tough-minded"
    pause 1.0
    screenshot "c1_06_whitney_uneasy.png"
    advance until "Pure imagination"
    pause 1.0
    screenshot "c1_07_rainsford_grim.png"
    advance until "There was no sound in the night"
    pause 1.5
    screenshot "c1_08_after_deck_profile.png"
    advance until "An abrupt sound startled him"
    pause 0.3
    screenshot "c1_09_shots.png"
    advance until "A short, hoarse cry"
    pause 1.0
    screenshot "c1_10_overboard.png"
    advance until "Rainsford remembered the shots"
    pause 1.5
    screenshot "c1_11_rocks.png"
    advance until "Pistol shot."
    pause 0.5
    screenshot "c1_12_pistol_shot.png"

    # II. The Château
    advance until "When he opened his eyes"
    pause 1.0
    screenshot "c2_01_jungle.png"
    advance until "Where there are pistol shots"
    pause 1.0
    screenshot "c2_02_jungle_profile.png"
    advance until "Bleak darkness was blacking out"
    pause 1.5
    screenshot "c2_03_chateau.png"
    advance until "He thought he heard steps within"
    pause 0.5
    screenshot "c2_04_knocker.png"
    advance until "Out of the snarl of beard"
    pause 1.0
    screenshot "c2_05_ivan.png"
    advance until "Don’t be alarmed"
    pause 1.0
    screenshot "c2_06_ivan_rainsford.png"
    advance until "I am General Zaroff"
    pause 1.0
    screenshot "c2_07_zaroff_host.png"
    advance until "It was to a huge, beam-ceilinged bedroom"
    pause 1.5
    screenshot "c2_08_guestroom.png"

    # III. The Most Dangerous Game
    advance until "You’ll have a cocktail"
    pause 1.0
    screenshot "c3_01_dinner.png"
    advance until "Here in my preserve"
    pause 1.0
    screenshot "c3_02_zaroff_main.png"
    advance until "I had to invent a new animal"
    pause 1.0
    screenshot "c3_03_zaroff_shadow.png"
    advance until "But you can’t mean"
    pause 1.0
    screenshot "c3_04_rainsford_grim.png"
    click "Scene Info"
    pause 1.0
    screenshot "c3_04b_scene_info_dinner.png"
    click "Close"
    pause 0.5
    advance until "Watch! Out there!"
    pause 1.0
    screenshot "c3_05_window.png"
    advance until "Civilized? And you shoot"
    pause 1.0
    screenshot "c3_06_window_two.png"
    advance until "He raised his hand, and Ivan"
    pause 1.0
    screenshot "c3_07_coffee.png"
    advance until "The lights from the windows"
    pause 1.0
    screenshot "c3_08_courtyard_hounds.png"
    advance until "A rather good lot"
    pause 1.0
    screenshot "c3_09_courtyard_zaroff.png"
    advance until "I hope that you will excuse me"
    pause 1.0
    screenshot "c3_10_courtyard_excuse.png"
    advance until "The bed was good"
    pause 1.5
    screenshot "c3_11_sleepless.png"
    advance until "He went to the window"
    pause 1.0
    screenshot "c3_12_window_hounds.png"

    # IV. Outdoor Chess
    advance until "General Zaroff did not appear until luncheon"
    pause 1.0
    screenshot "c4_01_luncheon.png"
    advance until "General, I wish to leave"
    pause 1.0
    screenshot "c4_02_leave.png"
    advance until "Tonight, we will hunt"
    pause 1.0
    screenshot "c4_03_hunt.png"
    advance until "He nodded toward the corner"
    pause 1.0
    screenshot "c4_04_trio.png"
    click "Scene Info"
    pause 1.0
    screenshot "c4_04b_scene_info_trio.png"
    click "Close"
    pause 0.5
    advance until "And if I win"
    pause 1.0
    screenshot "c4_05_terms.png"

    # V. The Fox and the Cat
    advance until "Rainsford had fought his way"
    pause 1.5
    screenshot "c5_01_thicket.png"
    advance until "Night found him leg-weary"
    pause 1.5
    screenshot "c5_02_forest.png"
    advance until "It was General Zaroff. He made his way"
    pause 1.0
    screenshot "c5_03_tree_zaroff.png"
    advance until "Rainsford held his breath"
    pause 0.5
    screenshot "c5_04_heartbeat.png"
    advance until "I will not lose my nerve"
    pause 1.0
    screenshot "c5_05_nerve.png"
    advance until "Even as he touched it"
    pause 0.5
    screenshot "c5_06_man_catcher.png"
    advance until "When the general, nursing"
    pause 1.5
    screenshot "c5_07_swamp.png"
    advance until "Then he felt an impulse to cry"
    pause 0.5
    screenshot "c5_08_pit.png"
    advance until "You’ve done well, Rainsford"
    pause 1.0
    screenshot "c5_09_swamp_zaroff.png"

    # VI. The Pack
    advance until "It was a distant sound"
    pause 1.0
    screenshot "c6_01_ridge.png"
    advance until "Rainsford knew he could do one of two things"
    pause 1.0
    screenshot "c6_02_ridge_rainsford.png"
    advance until "Straining his eyes"
    pause 1.0
    screenshot "c6_03_pack_trio.png"
    click "Scene Info"
    pause 1.0
    screenshot "c6_03b_scene_info_pack.png"
    click "Close"
    pause 0.5
    advance until "He had to stop to get his breath"
    pause 0.5
    screenshot "c6_04_knife.png"
    advance until "Nerve, nerve, nerve"
    pause 1.0
    screenshot "c6_05_nerve.png"
    advance until "A blue gap showed"
    pause 1.0
    screenshot "c6_06_cliff.png"
    advance until "When the general and his pack"
    pause 1.0
    screenshot "c6_07_cove.png"

    # VII. A Better Bed
    advance until "General Zaroff had an exceedingly good dinner"
    pause 1.0
    screenshot "c7_01_dinner_alone.png"
    advance until "He was deliciously tired"
    pause 1.5
    screenshot "c7_02_bedroom.png"
    advance until "A man, who had been hiding"
    pause 1.0
    screenshot "c7_03_rainsford_appears.png"
    advance until "The general made one of his deepest bows"
    pause 1.0
    screenshot "c7_04_on_guard.png"
    click "Scene Info"
    pause 1.0
    screenshot "c7_04b_scene_info_finale.png"
    click "Close"
    pause 0.5
    advance until "He had never slept"
    pause 2.0
    screenshot "c7_05_end_line.png"
    advance until screen "credits"
    pause 1.0
    screenshot "e01_credits_end.png"
    scroll pos (500, 600) amount 30
    pause 0.5
    move pos (500, 600)
    pause 0.5
    screenshot "e02_credits_end_hover.png"
    scroll pos (500, 600) amount 60
    pause 0.5
    move pos (500, 500)
    pause 0.5
    screenshot "e03_credits_sfx.png"
    scroll pos (500, 600) amount 60
    pause 0.5
    move pos (500, 650)
    pause 0.5
    screenshot "e04_credits_interface.png"
    move pos (1800, 1040)
    click "Back to the main menu"
    pause 2.0
    screenshot "e05_back_to_menu.png"

testcase ending:
    $ _test.transition_timeout = 0.05
    pause 1.0
    click "Start"
    advance until screen "credits"
    pause 1.0
    screenshot "30_ending_credits.png"
    click "Back to the main menu"
    pause 1.0
