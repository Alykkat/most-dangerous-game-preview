﻿## The Most Dangerous Game — adapted from Richard Connell's 1924 short story (public domain).
## Narration and dialogue follow Connell's text, lightly trimmed for pacing.

define r = Character("Rainsford", color="#e2cf96", image="rainsford")
define rt = Character("Rainsford", color="#e2cf96", what_italic=True, what_color="#d8d2c4")
define w = Character("Whitney", color="#a9c3d6", image="whitney")
define z = Character("General Zaroff", color="#d46a5f", image="zaroff")
define nielsen = Character("Captain Nielsen", color="#a9c3d6", what_italic=True)

style centered_text:
    outlines [(3, "#0d0a07", 0, 0)]

define flash = Fade(0.08, 0.0, 0.4, color="#fff")
define slow_dissolve = Dissolve(1.5)

## Each slot also resets alpha and offsets, so changing pose in the middle of an
## entrance (slow_rise) never leaves a figure half-faded.
## Stage slots. Each figure is centred on its slot, so two (or three) figures never overlap:
## two on stage use left_spot / right_spot, three use the trio_ slots at a smaller scale.
transform left_spot:
    zoom 0.88 xanchor 0.5 xpos 0.25 yalign 1.0 yoffset 0
    alpha 1.0 xoffset 0
transform right_spot:
    zoom 0.88 xanchor 0.5 xpos 0.75 yalign 1.0 yoffset 0
    alpha 1.0 xoffset 0
transform center_spot:
    zoom 0.88 xanchor 0.5 xpos 0.5 yalign 1.0 yoffset 0
    alpha 1.0 xoffset 0
transform trio_left:
    zoom 0.7 xanchor 0.5 xpos 0.18 yalign 1.0 yoffset 0
    alpha 1.0 xoffset 0
transform trio_center:
    zoom 0.7 xanchor 0.5 xpos 0.5 yalign 1.0 yoffset 0
    alpha 1.0 xoffset 0
transform trio_right:
    zoom 0.7 xanchor 0.5 xpos 0.83 yalign 1.0 yoffset 0
    alpha 1.0 xoffset 0
## The hounds are lifted clear of the dialogue box (they are smaller than the portraits).
transform hounds_spot:
    zoom 0.95 xanchor 0.5 xpos 0.3 yalign 1.0 yoffset -190
    alpha 1.0 xoffset 0
transform hounds_center:
    zoom 0.95 xanchor 0.5 xpos 0.5 yalign 1.0 yoffset -190
    alpha 1.0 xoffset 0
transform hounds_trio:
    zoom 0.8 xanchor 0.5 xpos 0.18 yalign 1.0 yoffset -190
    alpha 1.0 xoffset 0
transform slow_rise:
    yoffset 60 alpha 0.0
    easein 0.8 yoffset 0 alpha 1.0
transform shiver:
    linear 0.06 xoffset -6
    linear 0.06 xoffset 6
    repeat 4
    linear 0.06 xoffset 0

## A chapter card.
screen chapter_card(number, title):
    zorder 100
    add "images/ui/chapter_card.png"
    add Solid("#0d0a0780")
    vbox:
        align (0.5, 0.5)
        spacing 18
        add "images/ui/reticle.png" xalign 0.5 zoom 0.6
        text "CHAPTER " + number size 34 color "#c9a24a" xalign 0.5 kerning 8 font gui.interface_text_font
        text title size 88 color "#efe3c2" xalign 0.5 outlines [(3, "#0d0a07", 0, 2)]
        add Solid("#c9a24a", xysize=(260, 2)) xalign 0.5

label chapter(number, title):
    $ current_chapter = "Chapter " + number + " · " + title
    window hide
    show screen chapter_card(number, title)
    with Dissolve(0.8)
    pause 2.2
    hide screen chapter_card
    with Dissolve(0.8)
    return


label start:

    scene black
    window show
    centered "{size=+6}{color=#c9a24a}The Most Dangerous Game{/color}{/size}\n\nby Richard Connell (1924)\n\n{size=-6}Every word, painting, piece of music and sound in this game is in the public domain.\nClick {i}Scene Info{/i} in the top-right corner at any time to see the painting, characters and music of that moment, with links to learn more.{/size}"
    centered "{size=-4}Content note: this story from 1924 contains violence, death, and prejudiced language spoken by its villain.{/size}"

    ## ------------------------------------------------------------------ I
    play music m_hebrides fadein 3.0
    play ambient sfx_engine fadein 4.0 volume 0.6
    scene bg yacht with slow_dissolve
    call chapter("I", "Ship-Trap Island")

    show whitney at right_spot, slow_rise
    w "Off there to the right — somewhere — is a large island. It’s rather a mystery——"
    show rainsford at left_spot, slow_rise
    r "What island is it?"
    w "The old charts call it ‘Ship-Trap Island.’ A suggestive name, isn’t it? Sailors have a curious dread of the place. I don’t know why. Some superstition——"
    r "Can’t see it."
    "Rainsford peered through the dank tropical night that was palpable as it pressed its thick warm blackness in upon the yacht."
    w "You’ve good eyes, and I’ve seen you pick off a moose moving in the brown fall bush at four hundred yards, but even you can’t see four miles or so through a moonless Caribbean night."
    r "Nor four yards. Ugh! It’s like moist black velvet."
    w "It will be light enough in Rio. We should make it in a few days. I hope the jaguar guns have come from Purdey’s. We should have some good hunting up the Amazon. Great sport, hunting."
    r "The best sport in the world."
    w "For the hunter. Not for the jaguar."
    r "Don’t talk rot, Whitney. You’re a big-game hunter, not a philosopher. Who cares how a jaguar feels?"
    w "Perhaps the jaguar does."
    r "Bah! They’ve no understanding."
    w "Even so, I rather think they understand one thing — fear. The fear of pain and the fear of death."
    r "Nonsense. This hot weather is making you soft, Whitney. Be a realist. The world is made up of two classes — the hunters and the huntees. Luckily, you and I are hunters."
    r "Do you think we’ve passed that island yet?"
    w "I can’t tell in the dark. I hope so."
    r "Why?"
    w "The place has a reputation — a bad one."
    r "Cannibals?"
    w "Hardly. Even cannibals wouldn’t live in such a God-forsaken place. But it’s gotten into sailor lore, somehow. Didn’t you notice that the crew’s nerves seemed a bit jumpy today?"
    r "They were a bit strange, now you mention it. Even Captain Nielsen——"
    show whitney uneasy at right_spot with dissolve
    w "Yes, even that tough-minded old Swede, who’d go up to the devil himself and ask him for a light. Those fishy blue eyes held a look I never saw there before. All I could get out of him was:"
    nielsen "This place has an evil name among sea-faring men, sir."
    w "Then he said to me, very gravely:"
    nielsen "Don’t you feel anything?"
    w "As if the air about us was actually poisonous. Now, you mustn’t laugh when I tell you this — I did feel something like a sudden chill."
    w "There was no breeze. The sea was as flat as a plate-glass window. We were drawing near the island then. What I felt was a — a mental chill; a sort of sudden dread."
    show rainsford grim at left_spot with dissolve
    r "Pure imagination. One superstitious sailor can taint the whole ship’s company with his fear."
    w "Maybe. But sometimes I think sailors have an extra sense that tells them when they are in danger. Sometimes I think evil is a tangible thing — with wave lengths, just as sound and light have."
    show whitney at right_spot with dissolve
    show rainsford at left_spot
    w "An evil place can, so to speak, broadcast vibrations of evil. Anyhow, I’m glad we’re getting out of this zone. Well, I think I’ll turn in now, Rainsford."
    r "I’m not sleepy. I’m going to smoke another pipe up on the after deck."
    w "Good-night, then, Rainsford. See you at breakfast."
    r "Right. Good-night, Whitney."
    hide whitney with dissolve
    hide rainsford with dissolve

    play music m_moonlight fadein 3.0 fadeout 3.0
    show rainsford profile at center_spot with slow_dissolve
    "There was no sound in the night as Rainsford sat there but the muffled throb of the engine that drove the yacht swiftly through the darkness, and the swish and ripple of the wash of the propeller."
    "Rainsford, reclining in a steamer chair, indolently puffed on his favourite brier. The sensuous drowsiness of the night was on him."
    rt "It’s so dark that I could sleep without closing my eyes; the night would be my eyelids——"

    stop music
    play sound sfx_shots_far
    show rainsford at center_spot
    with flash
    "An abrupt sound startled him. Off to the right he heard it, and his ears, expert in such matters, could not be mistaken."
    play sound sfx_shots_far
    "Again he heard the sound, and again. Somewhere, off in the blackness, someone had fired a gun three times."
    "Rainsford sprang up and moved quickly to the rail, mystified. He strained his eyes in the direction from which the reports had come, but it was like trying to see through a blanket."
    "He leaped upon the rail and balanced himself there, to get greater elevation; his pipe, striking a rope, was knocked from his mouth. He lunged for it——"
    play music m_sea fadein 1.0
    stop ambient fadeout 1.0
    play sound sfx_splash
    scene bg overboard with vpunch
    "A short, hoarse cry came from his lips as he realized he had reached too far and had lost his balance. The cry was pinched off short as the blood-warm waters of the Caribbean Sea closed over his head."
    "He struggled up to the surface and tried to cry out, but the wash from the speeding yacht slapped him in the face and the salt water in his open mouth made him gag and strangle."
    "Desperately he struck out with strong strokes after the receding lights of the yacht, but he stopped before he had swum fifty feet. A certain cool-headedness had come to him; it was not the first time he had been in a tight place."
    "There was a chance that his cries could be heard by someone aboard the yacht, but that chance was slender, and grew more slender as the yacht raced on."
    "He wrestled himself out of his clothes, and shouted with all his power. The lights of the yacht became faint and ever-vanishing fireflies; then they were blotted out entirely by the night."

    scene bg rocks with slow_dissolve
    play ambient sfx_surf fadein 3.0 volume 0.5
    "Rainsford remembered the shots. They had come from the right, and doggedly he swam in that direction, swimming with slow, deliberate strokes, conserving his strength."
    "For a seemingly endless time he fought the sea. He began to count his strokes; he could do possibly a hundred more and then——"
    play sound sfx_yelp
    with vpunch
    "Rainsford heard a sound. It came out of the darkness, a high, screaming sound, the sound of an animal in an extremity of anguish and terror."
    "He did not recognize the animal that made the sound; he did not try to; with fresh vitality he swam toward the sound. He heard it again; then it was cut short by another noise, crisp, staccato."
    play sound sfx_shot volume 0.5
    with flash
    r "Pistol shot."
    play ambient sfx_surf fadein 2.0
    "Ten minutes of determined effort brought another sound to his ears — the most welcome he had ever heard — the muttering and growling of the sea breaking on a rocky shore."
    "He was almost on the rocks before he saw them; on a night less calm he would have been shattered against them. With his remaining strength he dragged himself from the swirling waters."
    "Jagged crags appeared to jut up into the opaqueness; he forced himself upward, hand over hand. Gasping, his hands raw, he reached a flat place at the top."
    "Dense jungle came down to the very edge of the cliffs. What perils that tangle of trees and underbrush might hold for him did not concern Rainsford just then."
    "All he knew was that he was safe from his enemy, the sea, and that utter weariness was on him. He flung himself down at the jungle edge and tumbled headlong into the deepest sleep of his life."
    stop music fadeout 3.0
    stop ambient fadeout 3.0
    scene black with slow_dissolve
    pause 1.0

    ## ------------------------------------------------------------------ II
    scene bg jungle with slow_dissolve
    call chapter("II", "The Château")
    play music m_moonlight fadein 3.0
    play sound sfx_birds
    "When he opened his eyes he knew from the position of the sun that it was late in the afternoon. Sleep had given him new vigour; a sharp hunger was picking at him. He looked about him, almost cheerfully."
    show rainsford profile at left_spot, slow_rise
    rt "Where there are pistol shots, there are men. Where there are men, there is food."
    "But what kind of men, he wondered, in so forbidding a place? An unbroken front of snarled and ragged jungle fringed the shore."
    "He saw no sign of a trail through the closely knit web of weeds and trees; it was easier to go along the shore, and Rainsford floundered along by the water. Not far from where he landed, he stopped."
    "Some wounded thing, by the evidence, a large animal, had thrashed about in the underbrush; the jungle weeds were crushed down and the moss was lacerated; one patch of weeds was stained crimson."
    "A small, glittering object not far away caught Rainsford’s eye and he picked it up. It was an empty cartridge."
    show rainsford at left_spot
    r "A twenty-two. That’s odd. It must have been a fairly large animal too. The hunter had his nerve with him to tackle it with a light gun. It’s clear that the brute put up a fight."
    r "I suppose the first three shots I heard was when the hunter flushed his quarry and wounded it. The last shot was when he trailed it here and finished it."
    "He examined the ground closely and found what he had hoped to find — the print of hunting boots. They pointed along the cliff in the direction he had been going."
    "Eagerly he hurried along, now slipping on a rotten log or a loose stone, but making headway; night was beginning to settle down on the island."
    hide rainsford with dissolve

    scene bg chateau with slow_dissolve
    "Bleak darkness was blacking out the sea and jungle when Rainsford sighted the lights. His first thought was that he had come upon a village, for there were many lights."
    "But as he forged along he saw to his great astonishment that all the lights were in one enormous building — a lofty structure with pointed towers plunging upward into the gloom."
    "His eyes made out the shadowy outlines of a palatial château; it was set on a high bluff, and on three sides of it cliffs dived down to where the sea licked greedy lips in the shadows."
    rt "Mirage."
    "But it was no mirage, he found, when he opened the tall spiked iron gate. The stone steps were real enough; the massive door with a leering gargoyle for a knocker was real enough; yet above it all hung an air of unreality."
    stop music fadeout 2.0
    "He lifted the knocker, and it creaked up stiffly, as if it had never before been used. He let it fall, and it startled him with its booming loudness."
    play sound sfx_knocker
    with vpunch
    "He thought he heard steps within; the door remained closed. Again Rainsford lifted the heavy knocker, and let it fall."
    play sound sfx_knocker
    with vpunch
    play sound sfx_door
    "The door opened then, opened as suddenly as if it were on a spring, and Rainsford stood blinking in the river of glaring gold light that poured out."
    show ivan at right_spot, slow_rise
    "The first thing Rainsford’s eyes discerned was the largest man Rainsford had ever seen — a gigantic creature, solidly made and black bearded to the waist."
    "In his hand the man held a long-barrelled revolver, and he was pointing it straight at Rainsford’s heart. Out of the snarl of beard two small eyes regarded Rainsford."
    show rainsford at left_spot, slow_rise
    r "Don’t be alarmed. I’m no robber. I fell off a yacht. My name is Sanger Rainsford of New York City."
    "The menacing look in the eyes did not change. The revolver pointed as rigidly as if the giant were a statue. He was dressed in uniform, a black uniform trimmed with gray astrakhan."
    r "I’m Sanger Rainsford of New York. I fell off a yacht. I am hungry."
    show ivan at right_spot, shiver
    "The man’s only answer was to raise with his thumb the hammer of his revolver. Then Rainsford saw the man’s free hand go to his forehead in a military salute, and he saw him click his heels together and stand at attention."
    hide ivan with dissolve
    play music m_nocturne fadein 2.0
    show zaroff host at right_spot, slow_rise
    "Another man was coming down the broad marble steps, an erect, slender man in evening clothes. He advanced to Rainsford and held out his hand."
    z "It is a very great pleasure and honour to welcome Mr. Sanger Rainsford, the celebrated hunter, to my home."
    "Automatically Rainsford shook the man’s hand."
    z "I’ve read your book about hunting snow leopards in Tibet, you see. I am General Zaroff."
    "Rainsford’s first impression was that the man was singularly handsome; his second was that there was an original, almost bizarre quality about the general’s face."
    "He was a tall man past middle age, for his hair was a vivid white; but his thick eyebrows and pointed military moustache were as black as the night from which Rainsford had come."
    "His eyes, too, were black and very bright. He had high cheek bones, a sharp-cut nose, a spare, dark face, the face of a man used to giving orders, the face of an aristocrat."
    "Turning to the giant in uniform, the general made a sign. The giant put away his pistol, saluted, withdrew."
    z "Ivan is an incredibly strong fellow, but he has the misfortune to be deaf and dumb. A simple fellow, but, I’m afraid, like all his race, a bit of a savage."
    r "Is he Russian?"
    z "He is a Cossack. So am I."
    "He smiled, and his smile showed red lips and pointed teeth."
    z "Come, we shouldn’t be chatting here. We can talk later. Now you want clothes, food, rest. You shall have them. This is a most restful spot."
    z "Follow Ivan, if you please, Mr. Rainsford. I was about to have my dinner when you came. I’ll wait for you. You’ll find that my clothes will fit you, I think."

    scene bg guestroom with slow_dissolve
    "It was to a huge, beam-ceilinged bedroom with a canopied bed big enough for six men that Rainsford followed the silent giant."
    "Ivan laid out an evening suit, and Rainsford, as he put it on, noticed that it came from a London tailor who ordinarily cut and sewed for none below the rank of duke."

    ## ------------------------------------------------------------------ III
    scene bg hall with slow_dissolve
    call chapter("III", "The Most Dangerous Game")
    "The dining room to which Ivan conducted him was in many ways remarkable. There was a medieval magnificence about it; it suggested a baronial hall of feudal times with its oaken panels, its high ceiling, its vast refectory table where two score men could sit down to eat."
    "About the hall were the mounted heads of many animals — lions, tigers, elephants, moose, bears; larger or more perfect specimens Rainsford had never seen. At the great table the general was sitting, alone."
    show zaroff host at right_spot, slow_rise
    show rainsford at left_spot, slow_rise
    z "You’ll have a cocktail, Mr. Rainsford."
    play sound sfx_glass
    "The cocktail was surpassingly good; and, Rainsford noted, the table appointments were of the finest — the linen, the crystal, the silver, the china."
    "They were eating borsch, the rich red soup with whipped cream so dear to Russian palates."
    z "We do our best to preserve the amenities of civilization here. Please forgive any lapses. We are well off the beaten track, you know. Do you think the champagne has suffered from its long ocean trip?"
    r "Not in the least."
    "He was finding the general a most thoughtful and affable host, a true cosmopolite. But there was one small trait of the general’s that made Rainsford uncomfortable. Whenever he looked up from his plate he found the general studying him, appraising him narrowly."
    z "Perhaps you were surprised that I recognized your name. You see, I read all books on hunting published in English, French, and Russian. I have but one passion in my life, Mr. Rainsford, and it is the hunt."
    r "You have some wonderful heads here. That Cape buffalo is the largest I ever saw."
    z "Oh, that fellow. Yes, he was a monster."
    r "Did he charge you?"
    z "Hurled me against a tree. Fractured my skull. But I got the brute."
    r "I’ve always thought that the Cape buffalo is the most dangerous of all big game."
    "For a moment the general did not reply; he was smiling his curious red-lipped smile."
    z "No. You are wrong, sir. The Cape buffalo is not the most dangerous big game."
    "He sipped his wine."
    show zaroff at right_spot with dissolve
    z "Here in my preserve on this island, I hunt more dangerous game."
    r "Is there big game on this island?"
    z "The biggest."
    r "Really?"
    z "Oh, it isn’t here naturally, of course. I have to stock the island."
    r "What have you imported, General? Tigers?"
    z "No. Hunting tigers ceased to interest me some years ago. I exhausted their possibilities, you see. No thrill left in tigers, no real danger. I live for danger, Mr. Rainsford."
    "The general took from his pocket a gold cigarette case and offered his guest a long black cigarette with a silver tip; it was perfumed and gave off a smell like incense."
    z "We will have some capital hunting, you and I. I shall be most glad to have your society."
    r "But what game——"
    z "I’ll tell you. You will be amused, I know. I think I may say, in all modesty, that I have done a rare thing. I have invented a new sensation. May I pour you another glass of port, Mr. Rainsford?"
    r "Thank you, General."
    z "God makes some men poets. Some He makes kings, some beggars. Me He made a hunter. My hand was made for the trigger, my father said."
    z "He was a very rich man with a quarter of a million acres in the Crimea, and he was an ardent sportsman. When I was only five years old he gave me a little gun, specially made in Moscow for me, to shoot sparrows with."
    z "When I shot some of his prize turkeys with it, he did not punish me; he complimented me on my marksmanship. I killed my first bear in the Caucasus when I was ten. My whole life has been one prolonged hunt."
    z "I went into the army — it was expected of noblemen’s sons — and for a time commanded a division of Cossack cavalry, but my real interest was always the hunt. I have hunted every kind of game in every land."
    z "After the débâcle in Russia I left the country, for it was imprudent for an officer of the Tsar to stay there. Many noble Russians lost everything. I, luckily, had invested heavily in American securities, so I shall never have to open a tea room in Monte Carlo or drive a taxi in Paris."
    z "Naturally, I continued to hunt — grizzlies in your Rockies, crocodiles in the Ganges, rhinoceroses in East Africa. It was in Africa that the Cape buffalo hit me and laid me up for six months."
    z "As soon as I recovered I started for the Amazon to hunt jaguars, for I had heard they were unusually cunning. They weren’t."
    "The Cossack sighed."
    z "They were no match at all for a hunter with his wits about him, and a high-powered rifle. I was bitterly disappointed."
    z "I was lying in my tent with a splitting headache one night when a terrible thought pushed its way into my mind. Hunting was beginning to bore me! And hunting, remember, had been my life."
    z "I have heard that in America business men often go to pieces when they give up the business that has been their life."
    r "Yes, that’s so."
    z "I had no wish to go to pieces. I must do something. Now, mine is an analytical mind, Mr. Rainsford. Doubtless that is why I enjoy the problems of the chase."
    r "No doubt, General Zaroff."
    z "So I asked myself why the hunt no longer fascinated me. You are much younger than I am, Mr. Rainsford, and have not hunted as much, but you perhaps can guess the answer."
    r "What was it?"
    z "Simply this: hunting had ceased to be what you call ‘a sporting proposition.’ It had become too easy. I always got my quarry. Always. There is no greater bore than perfection."
    "The general lit a fresh cigarette."
    z "No animal had a chance with me any more. That is no boast; it is a mathematical certainty. The animal had nothing but his legs and his instinct. Instinct is no match for reason."
    z "When I thought of this it was a tragic moment for me, I can tell you."
    "Rainsford leaned across the table, absorbed in what his host was saying."
    z "It came to me as an inspiration what I must do."
    r "And that was?"
    "The general smiled the quiet smile of one who has faced an obstacle and surmounted it with success."
    show zaroff shadow at right_spot with dissolve
    z "I had to invent a new animal to hunt."
    r "A new animal? You’re joking."
    play music m_macabre fadein 2.0 fadeout 2.0
    z "Not at all. I never joke about hunting. I needed a new animal. I found one. So I bought this island, built this house, and here I do my hunting."
    z "The island is perfect for my purposes — there are jungles with a maze of trails in them, hills, swamps——"
    r "But the animal, General Zaroff?"
    z "Oh, it supplies me with the most exciting hunting in the world. No other hunting compares with it for an instant. Every day I hunt, and I never grow bored now, for I have a quarry with which I can match my wits."
    "Rainsford’s bewilderment showed in his face."
    z "I wanted the ideal animal to hunt. So I said, ‘What are the attributes of an ideal quarry?’ And the answer was, of course, ‘It must have courage, cunning, and, above all, it must be able to reason.’"
    r "But no animal can reason."
    z "My dear fellow, there is one that can."
    show rainsford grim at left_spot, shiver
    r "But you can’t mean——"
    z "And why not?"
    r "I can’t believe you are serious, General Zaroff. This is a grisly joke."
    z "Why should I not be serious? I am speaking of hunting."
    r "Hunting? Great Guns, General Zaroff, what you speak of is murder."
    "The general laughed with entire good nature. He regarded Rainsford quizzically."
    z "I refuse to believe that so modern and civilized a young man as you seem to be harbours romantic ideas about the value of human life. Surely your experiences in the war——"
    r "Did not make me condone cold-blooded murder."
    z "How extraordinarily droll you are! One does not expect nowadays to find a young man of the educated class, even in America, with such a naïve, and, if I may say so, mid-Victorian point of view. It’s like finding a snuffbox in a limousine."
    z "Ah, well, doubtless you had Puritan ancestors. So many Americans appear to have had. I’ll wager you’ll forget your notions when you go hunting with me. You’ve a genuine new thrill in store for you, Mr. Rainsford."
    r "Thank you, I’m a hunter, not a murderer."
    z "Dear me, again that unpleasant word. But I think I can show you that your scruples are quite ill founded."
    r "Yes?"
    z "Life is for the strong, to be lived by the strong, and, if needs be, taken by the strong. The weak of the world were put here to give the strong pleasure. I am strong. Why should I not use my gift? If I wish to hunt, why should I not?"
    z "I hunt the scum of the earth: sailors from tramp ships — lascars, blacks, Chinese, whites, mongrels — a thoroughbred horse or hound is worth more than a score of them."
    r "But they are men."
    z "Precisely. That is why I use them. It gives me pleasure. They can reason, after a fashion. So they are dangerous."
    r "But where do you get them?"
    "The general’s left eyelid fluttered down in a wink."
    z "This island is called Ship Trap. Sometimes an angry god of the high seas sends them to me. Sometimes, when Providence is not so kind, I help Providence a bit. Come to the window with me."

    scene bg chateau with dissolve
    show zaroff at right_spot
    z "Watch! Out there!"
    "Rainsford’s eyes saw only blackness, and then, as the general pressed a button, far out to sea Rainsford saw the flash of lights."
    play sound sfx_switch
    with flash
    z "They indicate a channel where there’s none; giant rocks with razor edges crouch like a sea monster with wide-open jaws. They can crush a ship as easily as I crush this nut."
    play sound sfx_crack
    with vpunch
    "He dropped a walnut on the hardwood floor and brought his heel grinding down on it."
    z "Oh, yes, I have electricity. We try to be civilized here."
    show rainsford grim at left_spot
    r "Civilized? And you shoot down men?"
    "A trace of anger was in the general’s black eyes, but it was there for but a second."
    z "Dear me, what a righteous young man you are! I assure you I do not do the thing you suggest. That would be barbarous. I treat these visitors with every consideration. They get plenty of good food and exercise. They get into splendid physical condition. You shall see for yourself tomorrow."
    r "What do you mean?"
    z "We’ll visit my training school. It’s in the cellar. I have about a dozen pupils down there now. They’re from the Spanish bark Sanlúcar that had the bad luck to go on the rocks out there. A very inferior lot, I regret to say. Poor specimens and more accustomed to the deck than to the jungle."

    scene bg hall with dissolve
    show zaroff host at right_spot
    show rainsford grim at left_spot
    "He raised his hand, and Ivan, who served as waiter, brought thick Turkish coffee. Rainsford, with an effort, held his tongue in check."
    z "It’s a game, you see. I suggest to one of them that we go hunting. I give him a supply of food and an excellent hunting knife. I give him three hours’ start. I am to follow, armed only with a pistol of the smallest caliber and range."
    z "If my quarry eludes me for three whole days, he wins the game. If I find him——"
    "The general smiled."
    z "——he loses."
    r "Suppose he refuses to be hunted?"
    z "Oh, I give him his option, of course. He need not play that game if he doesn’t wish to. If he does not wish to hunt, I turn him over to Ivan."
    z "Ivan once had the honour of serving as official knouter to the Great White Czar, and he has his own ideas of sport. Invariably, Mr. Rainsford, invariably they choose the hunt."
    r "And if they win?"
    z "To date I have not lost."
    z "I don’t wish you to think me a braggart, Mr. Rainsford. Many of them afford only the most elementary sort of problem. Occasionally I strike a tartar. One almost did win. I eventually had to use the dogs."
    r "The dogs?"
    z "This way, please. I’ll show you."

    scene bg chateau with dissolve
    show hounds at hounds_spot with slow_dissolve
    play ambient sfx_hounds fadein 2.0 volume 0.25
    "The lights from the windows sent a flickering illumination that made grotesque patterns on the courtyard below, and Rainsford could see moving about there a dozen or so huge black shapes; as they turned toward him, their eyes glittered greenly."
    show zaroff at right_spot with dissolve
    z "A rather good lot, I think. They are let out at seven every night. If anyone should try to get into my house — or out of it — something extremely regrettable would occur to him."
    "He hummed a snatch of song from the Folies Bergère."
    z "And now, I want to show you my new collection of heads. Will you come with me to the library?"
    hide hounds
    show rainsford grim at left_spot
    with dissolve
    stop ambient fadeout 2.0
    r "I hope that you will excuse me tonight, General Zaroff. I’m really not feeling well."
    z "Ah, indeed? Well, I suppose that’s only natural, after your long swim. You need a good, restful night’s sleep. Tomorrow you’ll feel like a new man, I’ll wager. Then we’ll hunt, eh? I’ve one rather promising prospect——"
    hide rainsford with moveoutleft
    "Rainsford was hurrying from the room."
    z "Sorry you can’t go with me tonight. I expect rather fair sport — a big, strong, black. He looks resourceful—— Well, good night, Mr. Rainsford; I hope you have a good night’s rest."

    play music m_clair fadein 3.0 fadeout 2.0
    play ambient sfx_crickets fadein 3.0
    scene bg guestroom with slow_dissolve
    "The bed was good, and the pajamas of the softest silk, and he was tired in every fibre of his being, but nevertheless Rainsford could not quiet his brain with the opiate of sleep. He lay, eyes wide open."
    "Once he thought he heard stealthy steps in the corridor outside his room. He sought to throw open the door; it would not open."
    scene bg chateau with dissolve
    show hounds at hounds_center with dissolve
    "He went to the window and looked out. His room was high up in one of the towers. The lights of the château were out now, and it was dark and silent; but there was a fragment of sallow moon, and by its wan light he could see, dimly, the courtyard."
    "There, weaving in and out in the pattern of shadow, were black, noiseless forms; the hounds heard him at the window and looked up, expectantly, with their green eyes."
    scene bg guestroom with dissolve
    "Rainsford went back to the bed and lay down. By many methods he tried to put himself to sleep."
    stop music fadeout 2.0
    "He had achieved a doze when, just as morning began to come, he heard, far off in the jungle, the faint report of a pistol."
    stop ambient fadeout 1.0
    play sound sfx_shot volume 0.3
    with flash

    ## ------------------------------------------------------------------ IV
    scene bg hall with slow_dissolve
    call chapter("IV", "Outdoor Chess")
    play music m_nocturne fadein 2.0
    show zaroff host at right_spot, slow_rise
    "General Zaroff did not appear until luncheon. He was dressed faultlessly in the tweeds of a country squire. He was solicitous about the state of Rainsford’s health."
    show rainsford at left_spot, slow_rise
    z "As for me, I do not feel so well. I am worried, Mr. Rainsford. Last night I detected traces of my old complaint."
    "To Rainsford’s questioning glance the general said:"
    z "Ennui. Boredom."
    "Then, taking a second helping of Crêpes Suzette, the general explained:"
    z "The hunting was not good last night. The fellow lost his head. He made a straight trail that offered no problems at all. That’s the trouble with these sailors; they have dull brains to begin with, and they do not know how to get about in the woods."
    z "They do excessively stupid and obvious things. It’s most annoying. Will you have another glass of Chablis, Mr. Rainsford?"
    show rainsford grim at left_spot with dissolve
    r "General, I wish to leave this island at once."
    z "But, my dear fellow, you’ve only just come. You’ve had no hunting——"
    r "I wish to go today."
    "He saw the dead black eyes of the general on him, studying him. General Zaroff’s face suddenly brightened. He filled Rainsford’s glass with venerable Chablis from a dusty bottle."
    play music m_macabre fadein 2.0 fadeout 2.0
    show zaroff shadow at right_spot with dissolve
    z "Tonight, we will hunt — you and I."
    r "No, general. I will not hunt."
    "The general shrugged his shoulders and delicately ate a hothouse grape."
    z "As you wish, my friend. The choice rests entirely with you. But may I not venture to suggest that you will find my idea of sport more diverting than Ivan’s?"
    show rainsford grim at trio_left
    show ivan at trio_center
    show zaroff shadow at trio_right
    with dissolve
    "He nodded toward the corner to where the giant stood, scowling, his thick arms crossed on his hogshead of chest."
    r "You don’t mean——"
    z "My dear fellow, have I not told you I always mean what I say about hunting? This is really an inspiration. I drink to a foeman worthy of my steel — at last."
    play sound sfx_glass
    "The general raised his glass, but Rainsford sat staring at him."
    hide ivan
    show rainsford grim at left_spot
    show zaroff host at right_spot
    with dissolve
    z "You’ll find this game worth playing. Your brain against mine. Your wood-craft against mine. Your strength and stamina against mine. Outdoor chess! And the stake is not without value, eh?"
    r "And if I win——"
    z "I’ll cheerfully acknowledge myself defeated if I do not find you by midnight of the third day. My sloop will place you on the mainland near a town."
    "The general read what Rainsford was thinking."
    z "Oh, you can trust me. I will give you my word as a gentleman and a sportsman. Of course you, in turn, must agree to say nothing of your visit here."
    r "I’ll agree to nothing of the kind."
    z "Oh, in that case—— But why discuss that now? Three days hence we can discuss it over a bottle of Veuve Clicquot, unless——"
    "The general sipped his wine. Then a businesslike air animated him."
    z "Ivan will supply you with hunting clothes, food, a knife. I suggest you wear moccasins; they leave a poorer trail. I suggest, too, that you avoid the big swamp in the southeast corner of the island. We call it Death Swamp. There’s quicksand there."
    z "One foolish fellow tried it. The deplorable part of it was that Lazarus followed him. You can imagine my feelings, Mr. Rainsford. I loved Lazarus; he was the finest hound in my pack."
    z "Well, I must beg you to excuse me now. I always take a siesta after lunch. You’ll hardly have time for a nap, I fear. You’ll want to start, no doubt."
    z "I shall not follow till dusk. Hunting at night is so much more exciting than by day, don’t you think? Au revoir, Mr. Rainsford, au revoir."
    hide zaroff with dissolve
    "General Zaroff, with a deep, courtly bow, strolled from the room."
    "From another door came Ivan. Under one arm he carried khaki hunting clothes, a haversack of food, a leather sheath containing a long-bladed hunting knife; his right hand rested on a cocked revolver thrust in the crimson sash about his waist..."
    stop music fadeout 2.0
    scene black with slow_dissolve

    ## ------------------------------------------------------------------ V
    scene bg thicket with slow_dissolve
    call chapter("V", "The Fox and the Cat")
    play music m_baldmtn fadein 2.0
    show rainsford grim at left_spot, slow_rise
    "Rainsford had fought his way through the bush for two hours."
    r "I must keep my nerve. I must keep my nerve."
    "He had not been entirely clear-headed when the château gates snapped shut behind him. His whole idea at first was to put distance between himself and General Zaroff; and, to this end, he had plunged along, spurred on by the sharp rowels of something very like panic."
    "Now he had got a grip on himself, had stopped, and was taking stock of himself and the situation. He saw that straight flight was futile; inevitably it would bring him face to face with the sea."
    "He was in a picture with a frame of water, and his operations, clearly, must take place within that frame."
    r "I’ll give him a trail to follow."
    "He struck off from the rude path he had been following into the trackless wilderness. He executed a series of intricate loops; he doubled on his trail again and again, recalling all the lore of the fox hunt, and all the dodges of the fox."
    hide rainsford with dissolve

    scene bg forest with slow_dissolve
    play ambient sfx_crickets fadein 3.0
    "Night found him leg-weary, with hands and face lashed by the branches, on a thickly wooded ridge. He knew it would be insane to blunder on through the dark, even if he had the strength."
    rt "I have played the fox, now I must play the cat of the fable."
    "A big tree with a thick trunk and outspread branches was near by, and, taking care to leave not the slightest mark, he climbed up into the crotch, and, stretching out on one of the broad limbs, after a fashion, rested."
    "Rest brought him new confidence and almost a feeling of security. Even so zealous a hunter as General Zaroff could not trace him there, he told himself; only the devil himself could follow that complicated trail through the jungle after dark."
    rt "But perhaps the general was a devil——"
    "An apprehensive night crawled slowly by like a wounded snake and sleep did not visit Rainsford, although the silence of a dead world was on the jungle."
    play sound sfx_crow
    "Toward morning when a dingy gray was varnishing the sky, the cry of some startled bird focused Rainsford’s attention in that direction. Something was coming through the bush, coming slowly, carefully, coming by the same winding way Rainsford had come."
    "He flattened himself down on the limb and, through a screen of leaves almost as thick as tapestry, he watched... That which was approaching was a man."
    play sound sfx_footsteps
    show zaroff shadow at right_spot with slow_dissolve
    "It was General Zaroff. He made his way along with his eyes fixed in utmost concentration on the ground before him. He paused, almost beneath the tree, dropped to his knees and studied the ground."
    "Rainsford’s impulse was to hurl himself down like a panther, but he saw that the general’s right hand held something metallic — a small automatic pistol."
    "The hunter shook his head several times, as if he were puzzled. Then he straightened up and took from his case one of his black cigarettes; its pungent incense-like smoke floated up to Rainsford’s nostrils."
    play sound sfx_heartbeat loop
    "Rainsford held his breath. The general’s eyes had left the ground and were traveling inch by inch up the tree. Rainsford froze there, every muscle tensed for a spring."
    "But the sharp eyes of the hunter stopped before they reached the limb where Rainsford lay; a smile spread over his brown face. Very deliberately he blew a smoke ring into the air; then he turned his back on the tree and walked carelessly away, back along the trail he had come."
    stop sound fadeout 1.0
    play sound sfx_footsteps volume 0.4
    hide zaroff with Dissolve(2.0)
    "The swish of the underbrush against his hunting boots grew fainter and fainter."
    "The pent-up air burst hotly from Rainsford’s lungs. His first thought made him feel sick and numb. The general could follow a trail through the woods at night; he could follow an extremely difficult trail; he must have uncanny powers; only by the merest chance had the Cossack failed to see his quarry."
    "Rainsford’s second thought was even more terrible. It sent a shudder of cold horror through his whole being. Why had the general smiled? Why had he turned back?"
    "Rainsford did not want to believe what his reason told him was true, but the truth was as evident as the sun that had by now pushed through the morning mists. The general was playing with him! The general was saving him for another day’s sport!"
    "The Cossack was the cat; he was the mouse. Then it was that Rainsford knew the full meaning of terror."
    show rainsford grim at left_spot with dissolve
    r "I will not lose my nerve. I will not."

    scene bg thicket with slow_dissolve
    stop ambient fadeout 3.0
    "He slid down from the tree, and struck off again into the woods. His face was set and he forced the machinery of his mind to function."
    "Three hundred yards from his hiding place he stopped where a huge dead tree leaned precariously on a smaller, living one. Throwing off his sack of food, Rainsford took his knife from its sheath and began to work with all his energy."
    "The job was finished at last, and he threw himself down behind a fallen log a hundred feet away. He did not have to wait long. The cat was coming again to play with the mouse."
    show zaroff shadow at right_spot with dissolve
    "Following the trail with the sureness of a bloodhound came General Zaroff. Nothing escaped those searching black eyes, no crushed blade of grass, no bent twig, no mark, no matter how faint, in the moss."
    "So intent was the Cossack on his stalking that he was upon the thing Rainsford had made before he saw it. His foot touched the protruding bough that was the trigger."
    play sound sfx_tree
    show zaroff shadow at right_spot, shiver
    with vpunch
    "Even as he touched it, the general sensed his danger and leaped back with the agility of an ape. But he was not quite quick enough; the dead tree, delicately adjusted to rest on the cut living one, crashed down and struck the general a glancing blow on the shoulder as it fell."
    "But for his alertness, he must have been smashed beneath it. He staggered, but he did not fall; nor did he drop his revolver. He stood there, rubbing his injured shoulder, and Rainsford, with fear again gripping his heart, heard the general’s mocking laugh ring through the jungle."
    z "Rainsford, if you are within sound of my voice, as I suppose you are, let me congratulate you. Not many men know how to make a Malay man-catcher. Luckily for me I, too, have hunted in Malacca."
    z "You are proving interesting, Mr. Rainsford. I am going now to have my wound dressed; it’s only a slight one. But I shall be back. I shall be back."
    hide zaroff with dissolve

    play music m_funebre fadein 3.0 fadeout 3.0
    scene bg swamp with slow_dissolve
    play ambient sfx_crickets fadein 4.0
    "When the general, nursing his bruised shoulder, had gone, Rainsford took up his flight again. It was flight now, a desperate, hopeless flight, that carried him on for some hours."
    "Dusk came, then darkness, and still he pressed on. The ground grew softer under his moccasins; the vegetation grew ranker, denser; insects bit him savagely."
    play sound sfx_mud
    with vpunch
    "Then, as he stepped forward, his foot sank into the ooze. He tried to wrench it back, but the muck sucked viciously at his foot as if it were a giant leech. With a violent effort, he tore his feet loose."
    "He knew where he was now. Death Swamp and its quicksand."
    "His hands were tight closed as if his nerve were something tangible that someone in the darkness was trying to tear from his grip. The softness of the earth had given him an idea."
    "He stepped back from the quicksand a dozen feet or so and, like some huge prehistoric beaver, he began to dig."
    "Rainsford had dug himself in in France when a second’s delay meant death. That had been a placid pastime compared to his digging now."
    "The pit grew deeper; when it was above his shoulders, he climbed out and from some hard saplings cut stakes and sharpened them to a fine point. These stakes he planted in the bottom of the pit with the points sticking up."
    "With flying fingers he wove a rough carpet of weeds and branches and with it he covered the mouth of the pit. Then, wet with sweat and aching with tiredness, he crouched behind the stump of a lightning-charred tree."
    "He knew his pursuer was coming; he heard the padding sound of feet on the soft earth, and the night breeze brought him the perfume of the general’s cigarette."
    play sound sfx_heartbeat loop
    "It seemed to Rainsford that the general was coming with unusual swiftness; he was not feeling his way along, foot by foot. Rainsford, crouching there, could not see the general, nor could he see the pit. He lived a year in a minute."
    play sound sfx_branches
    queue sound sfx_yelp
    with vpunch
    "Then he felt an impulse to cry aloud with joy, for he heard the sharp crackle of the breaking branches as the cover of the pit gave way; he heard the sharp scream of pain as the pointed stakes found their mark."
    "He leaped up from his place of concealment. Then he cowered back. Three feet from the pit a man was standing, with an electric torch in his hand."
    show zaroff shadow at right_spot with dissolve
    z "You’ve done well, Rainsford. Your Burmese tiger pit has claimed one of my best dogs. Again you score."
    z "I think, Mr. Rainsford, I’ll see what you can do against my whole pack. I’m going home for a rest now. Thank you for a most amusing evening."
    hide zaroff with dissolve
    stop music fadeout 3.0
    stop ambient fadeout 3.0
    scene black with slow_dissolve

    ## ------------------------------------------------------------------ VI
    scene bg ridge with slow_dissolve
    call chapter("VI", "The Pack")
    "At daybreak Rainsford, lying near the swamp, was awakened by a sound that made him know that he had new things to learn about fear."
    play music m_mountain fadein 1.0
    play ambient sfx_hounds fadein 4.0 volume 0.35
    "It was a distant sound, faint and wavering, but he knew it. It was the baying of a pack of hounds."
    show rainsford grim at left_spot, slow_rise
    "Rainsford knew he could do one of two things. He could stay where he was and wait. That was suicide. He could flee. That was postponing the inevitable."
    "For a moment he stood there, thinking. An idea that held a wild chance came to him, and, tightening his belt, he headed away from the swamp."
    hide rainsford with dissolve
    play ambient sfx_hounds volume 0.7
    "The baying of the hounds drew nearer, then still nearer, nearer, ever nearer. On a ridge Rainsford climbed a tree. Down a watercourse, not a quarter of a mile away, he could see the bush moving."
    show hounds hunt at hounds_trio
    show ivan at trio_center
    show zaroff shadow at trio_right
    with dissolve
    "Straining his eyes, he saw the lean figure of General Zaroff; just ahead of him Rainsford made out another figure whose wide shoulders surged through the tall jungle weeds; it was the giant Ivan, and he seemed pulled forward by some unseen force."
    "Rainsford knew that Ivan must be holding the pack in leash."
    hide zaroff
    hide ivan
    hide hounds
    with dissolve
    "They would be on him any minute now. His mind worked frantically. He thought of a native trick he had learned in Uganda. He slid down the tree."
    "He caught hold of a springy young sapling and to it he fastened his hunting knife, with the blade pointing down the trail; with a bit of wild grapevine he tied back the sapling. Then he ran for his life."
    "The hounds raised their voices as they hit the fresh scent. Rainsford knew now how an animal at bay feels."
    stop music
    stop ambient
    play sound sfx_yelp
    "He had to stop to get his breath. The baying of the hounds stopped abruptly, and Rainsford’s heart stopped too. They must have reached the knife."
    show zaroff shadow at right_spot with dissolve
    "He shinned excitedly up a tree and looked back. His pursuers had stopped. But the hope that was in Rainsford’s brain when he climbed died, for he saw in the shallow valley that General Zaroff was still on his feet."
    "But Ivan was not. The knife, driven by the recoil of the springing tree, had not wholly failed."
    hide zaroff with dissolve
    play music m_mountain
    play ambient sfx_hounds volume 0.8
    "Rainsford had hardly tumbled to the ground when the pack took up the cry again."
    show rainsford grim at center_spot
    r "Nerve, nerve, nerve!"

    scene bg cliff with vpunch
    play sound sfx_surf loop volume 0.6
    "A blue gap showed between the trees dead ahead. Ever nearer drew the hounds. Rainsford forced himself on toward that gap. He reached it. It was the shore of the sea."
    "Across a cove he could see the gloomy gray stone of the château. Twenty feet below him the sea rumbled and hissed. Rainsford hesitated. He heard the hounds."
    stop music
    stop ambient fadeout 0.5
    "Then he leaped far out into the sea..."
    stop sound
    play sound sfx_splash
    scene black with flash
    pause 1.0

    scene bg chateau with slow_dissolve
    play ambient sfx_surf fadein 3.0 volume 0.4
    show hounds hunt at hounds_spot
    show zaroff at right_spot
    with dissolve
    "When the general and his pack reached the place by the sea, the Cossack stopped. For some minutes he stood regarding the blue-green expanse of water. He shrugged his shoulders."
    play music m_butterfly fadein 3.0
    "Then he sat down, took a drink of brandy from a silver flask, lit a cigarette, and hummed a bit from “Madama Butterfly.”"

    ## ------------------------------------------------------------------ VII
    scene bg hall with slow_dissolve
    stop ambient fadeout 2.0
    call chapter("VII", "A Better Bed")
    show zaroff host at right_spot, slow_rise
    "General Zaroff had an exceedingly good dinner in his great panelled dining hall that evening. With it he had a bottle of Pol Roger and half a bottle of Chambertin."
    "Two slight annoyances kept him from perfect enjoyment. One was the thought that it would be difficult to replace Ivan; the other was that his quarry had escaped him; of course, the American hadn’t played the game — so thought the general as he tasted his after-dinner liqueur."
    "In his library he read, to soothe himself, from the works of Marcus Aurelius. At ten he went up to his bedroom."

    scene bg zbedroom with slow_dissolve
    show zaroff host at right_spot
    "He was deliciously tired, he said to himself, as he locked himself in. There was a little moonlight, so, before turning on his light, he went to the window and looked down at the courtyard."
    "He could see the great hounds, and he called to them:"
    z "Better luck another time."
    "Then he switched on the light."
    play sound sfx_switch
    with flash
    show rainsford grim at left_spot with vpunch
    "A man, who had been hiding in the curtains of the bed, was standing there."
    stop music
    z "Rainsford! How in God’s name did you get here?"
    r "Swam. I found it quicker than walking through the jungle."
    "The general sucked in his breath and smiled."
    z "I congratulate you. You have won the game."
    "Rainsford did not smile."
    r "I am still a beast at bay. Get ready, General Zaroff."
    show zaroff shadow at right_spot with dissolve
    "The general made one of his deepest bows."
    z "I see. Splendid! One of us is to furnish a repast for the hounds. The other will sleep in this very excellent bed. On guard, Rainsford..."
    scene black with Fade(0.5, 1.5, 0.5)
    pause 1.5

    play music m_butterfly fadein 2.0
    scene bg guestroom with Dissolve(3.0)
    centered "{size=+8}He had never slept in a better bed, Rainsford decided.{/size}"
    centered "{size=+10}{color=#c9a24a}THE END{/color}{/size}"

    $ persistent.finished_once = True
    window hide
    $ quick_menu = False
    call screen credits(ending=True)
    $ quick_menu = True
    return
